namespace FeatureFlaggingDotNet.FeatureFlagging.Domain.Models
{
    public class WeatherForecast
    {
        public DateOnly Date { get; set; }

        public string? Temperature { get; set; }

        public string? Summary { get; set; }
    }
}