﻿namespace FeatureFlaggingDotNet.FeatureFlagging.Domain.Models
{
    public static class WeatherTypes
    {
        public static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };
    }
}
