using FeatureFlaggingDotNet.FeatureFlagging.Domain.Models;
using FeatureFlaggingDotNet.FeatureFlagging.Domain.Services;
using Microsoft.AspNetCore.Mvc;

namespace FeatureFlaggingDotNet.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IConfiguration _configuration;
        private readonly ICelsiusOperations _celsiusOperations;
        private readonly IFahrenheitOperations _fahrenheitOperations;
        private readonly IKelvinOperations _kelvinOperations;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, IConfiguration configuration,
        ICelsiusOperations celsiusOperations,
        IFahrenheitOperations fahrenheitOperations,
        IKelvinOperations kelvinOperations)
        {
            _logger = logger;
            _configuration = configuration;
            _celsiusOperations = celsiusOperations;
            _fahrenheitOperations = fahrenheitOperations;
            _kelvinOperations = kelvinOperations;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public async Task<IEnumerable<WeatherForecast>> Get() //Fahrenheit  Celsius  Kelvin
        {
            var temperatureType = "Celsius";
            //var temperatureType = _configuration.GetValue<string>("TemperatureType");
            Console.Write("feature flagged temprature type : {0}", temperatureType);

            return temperatureType switch
            {
                "Celsius" => _celsiusOperations.GetWeather(temperatureType),
                "Fahrenheit" => _fahrenheitOperations.GetWeather(temperatureType),
                "Kelvin" => _kelvinOperations.GetWeather(temperatureType),
                _ => _celsiusOperations.GetWeather(temperatureType),
            };
        }
    }
}