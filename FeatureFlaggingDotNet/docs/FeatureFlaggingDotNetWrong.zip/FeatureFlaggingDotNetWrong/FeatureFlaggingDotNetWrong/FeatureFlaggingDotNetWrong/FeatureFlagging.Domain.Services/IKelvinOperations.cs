using FeatureFlaggingDotNet.FeatureFlagging.Domain.Models;

namespace FeatureFlaggingDotNet.FeatureFlagging.Domain.Services
{
    public interface IKelvinOperations
    {
        IEnumerable<WeatherForecast> GetWeather(string temperatureType);
    }
}
