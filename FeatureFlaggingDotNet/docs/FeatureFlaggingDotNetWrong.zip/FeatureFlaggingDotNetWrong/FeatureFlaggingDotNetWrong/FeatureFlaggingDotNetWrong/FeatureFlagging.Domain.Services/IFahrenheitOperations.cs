using FeatureFlaggingDotNet.FeatureFlagging.Domain.Models;

namespace FeatureFlaggingDotNet.FeatureFlagging.Domain.Services
{
    public interface IFahrenheitOperations
    {
        IEnumerable<WeatherForecast> GetWeather(string temperatureType);
    }
}
