using FeatureFlaggingDotNet.FeatureFlagging.Domain.Models;

namespace FeatureFlaggingDotNet.FeatureFlagging.Domain.Services
{
    public interface ICelsiusOperations
    {
        IEnumerable<WeatherForecast> GetWeather(string temperatureType);
    }
}
